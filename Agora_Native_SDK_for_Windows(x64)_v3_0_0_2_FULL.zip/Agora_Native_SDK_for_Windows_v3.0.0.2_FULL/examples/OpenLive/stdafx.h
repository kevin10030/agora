#ifndef STDAFX_H
#define STDAFX_H

#include <Memory>
#include <qevent.h>
#include <QDebug>
#include "agoraconfig.h"
extern CAgoraConfig gAgoraConfig;

#endif // STDAFX_H
